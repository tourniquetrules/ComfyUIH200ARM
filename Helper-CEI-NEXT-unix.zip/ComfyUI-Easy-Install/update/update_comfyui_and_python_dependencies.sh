#!/bin/bash

# Assuming the virtual environment is activated

bash update_comfyui.sh nopause

echo "-"
echo "This will try to update pytorch and all python dependencies."
echo "-"
echo "If you just want to update normally, close this and run update_comfyui.sh instead."
echo "-"
read -p "Press any key to continue..."

python -m uv pip install --upgrade torch torchvision torchaudio -r ../ComfyUI/requirements.txt pygit2

read -p "Press any key to continue..."
