#!/bin/bash

# Assuming the virtual environment is activated

python update.py ../ComfyUI/

if [ -f "update_new.py" ]; then
  mv -f update_new.py update.py
  echo "Running updater again since it got updated."
  python update.py ../ComfyUI/ --skip_self_update
fi

if [ -z "$1" ]; then
  read -p "Press any key to continue..."
fi
