#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

# Set arguments (re-define for standalone execution if needed, or assume sourced)
UV_ARGS="--no-cache --link-mode=copy"

# Assuming the virtual environment is activated
if ! command -v python &> /dev/null; then
    echo -e "${RED}Error: Python virtual environment not activated or python not found.${RESET}"
    echo -e "Please activate your virtual environment before running this script."
    exit 1
fi

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

# Erasing ~* folders in the current venv's site-packages
VENV_SITE_PACKAGES=$(python -c "import site; print(site.getsitepackages()[0])")
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

echo -e "${GREEN}::::::::::::::: Updating All Nodes :::::::::::::::${RESET}"
echo ""
python ComfyUI/custom_nodes/ComfyUI-Manager/cm-cli.py update all
echo ""

# Restoring Numpy 1.26.4
echo -e "${GREEN}::::::::::::::: Restoring${YELLOW} Numpy 1.26.4 ${GREEN}:::::::::::::::${RESET}"
echo ""
python -m uv pip install --force-reinstall numpy==1.26.4 --no-deps $UV_ARGS
echo ""

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""
bash run_nvidia_gpu.sh
