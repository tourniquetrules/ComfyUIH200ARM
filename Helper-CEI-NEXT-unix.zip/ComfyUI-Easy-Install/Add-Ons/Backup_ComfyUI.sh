#!/bin/bash

# ============================================
# Backup_ComfyUI by VenimK v1.2
# Pixaroma Community Edition
# macOS and Linux conversion by VenimK
# Added restore functionality
# ============================================

# Set custom colors
# Primary: #029566 (Green)
# Secondary: #E1D297 (Beige)
# Accent: #B6A877 (Light Brown)

# Set colors and styles for better output (using tput for better compatibility)
if command -v tput >/dev/null 2>&1 && [ "$(tput colors)" -ge 256 ]; then
    # 256-color mode
    readonly PRIMARY=$(tput setaf 35)     # #029566
    readonly SECONDARY=$(tput setaf 187)  # #E1D297
    readonly ACCENT=$(tput setaf 144)     # #B6A877
    
    # Standard colors
    readonly RED=$(tput setaf 1)
    readonly GREEN=$(tput setaf 2)
    readonly YELLOW=$(tput setaf 3)
    readonly BLUE=$(tput setaf 4)
    readonly WHITE=$(tput setaf 7)
    
    # Text styles
    readonly BOLD=$(tput bold)
    readonly DIM=$(tput dim)
    readonly UNDERLINE=$(tput smul)
    readonly RESET=$(tput sgr0)
    
    # Background colors
    readonly BG_PRIMARY=$(tput setab 35)
    readonly BG_SECONDARY=$(tput setab 187)
    readonly BG_ACCENT=$(tput setab 144)
else
    # Fallback to 8-color mode
    readonly PRIMARY='\033[0;32m'     # Green as fallback
    readonly SECONDARY='\033[1;33m'   # Yellow as fallback
    readonly ACCENT='\033[0;33m'      # Brown as fallback
    
    # Standard colors
    readonly RED='\033[0;31m'
    readonly GREEN='\033[0;32m'
    readonly YELLOW='\033[1;33m'
    readonly BLUE='\033[0;34m'
    readonly WHITE='\033[1;37m'
    
    # Text styles
    readonly BOLD='\033[1m'
    readonly DIM='\033[2m'
    readonly UNDERLINE='\033[4m'
    readonly RESET='\033[0m'
    
    # Background colors (limited in 8-color mode)
    readonly BG_PRIMARY='\033[42m'
    readonly BG_SECONDARY='\033[43m'
    readonly BG_ACCENT='\033[43m'
fi

# Box drawing characters (using standard ASCII for maximum compatibility)
readonly BOX_TOP_LEFT="+"
readonly BOX_TOP_RIGHT="+"
readonly BOX_BOTTOM_LEFT="+"
readonly BOX_BOTTOM_RIGHT="+"
readonly BOX_VERTICAL="|"
readonly BOX_HORIZONTAL="-"
readonly BOX_JOINT_LEFT="+"
readonly BOX_JOINT_RIGHT="+"
readonly BOX_JOINT_TOP="+"
readonly BOX_JOINT_BOTTOM="+"
readonly BOX_CROSS="+"

# Icons with custom colors
readonly ICON_CHECK="${PRIMARY}✓${RESET}"
readonly ICON_WARN="${ACCENT}⚠${RESET}"
readonly ICON_ERROR="${RED}✗${RESET}"
readonly ICON_INFO="${SECONDARY}ℹ${RESET}"
readonly ICON_FOLDER="${SECONDARY}📁${RESET}"
readonly ICON_CLOCK="${ACCENT}🕒${RESET}"
readonly ICON_DISK="${PRIMARY}💾${RESET}"

# Configuration
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly COMFYUI_DIR="$SCRIPT_DIR/../ComfyUI"
readonly BACKUP_ROOT_DIR="$HOME/ComfyUI_Backups"
readonly TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
readonly BACKUP_DIR="${BACKUP_ROOT_DIR}/ComfyUI_backup_${TIMESTAMP}"

# Base directories to back up (relative to COMFYUI_DIR)
readonly BASE_BACKUP_DIRS=(
    "user"
    "input"
    "output"
    )

# Optional directories that can be included in backup
readonly OPTIONAL_BACKUP_DIRS=(
    "models"
    )

# Function to print a boxed title
print_boxed_title() {
    local title="$1"
    local title_length=${#title}
    local box_width=$((title_length + 8))
    
    # Calculate title padding
    local title_padding=$(( (box_width - ${#title} - 2) / 2 ))
    [ $title_padding -lt 1 ] && title_padding=1
    
    # Top border
    echo -ne "${PRIMARY}${BOLD}+"
    printf "%${box_width-2}s" | tr ' ' "-"
    echo -e "+${RESET}"
    
    # Title line with secondary background
    echo -ne "${PRIMARY}${BOLD}|${BG_SECONDARY}${BLACK}"
    printf "%${title_padding}s"
    echo -n " ${title} "
    printf "%${title_padding}s"
    [ $(( (box_width - ${#title}) % 2 )) -eq 1 ] && echo -n " "
    echo -e "${RESET}${PRIMARY}${BOLD}|${RESET}"
    
    # Bottom border
    echo -ne "${PRIMARY}${BOLD}${BOX_BOTTOM_LEFT}"
    printf "%${box_width-2}s" | tr ' ' "${BOX_HORIZONTAL}"
    echo -e "${BOX_BOTTOM_RIGHT}${RESET}\n"
}

# Function to print section header
print_section() {
    local title="$1"
    echo -e "${BOLD}${BLUE}${BOX_HORIZONTAL}${BOX_HORIZONTAL} ${title} ${BOX_HORIZONTAL}${BOX_HORIZONTAL}${RESET}"
}

# Function to print a menu
print_menu() {
    local title="$1"
    local options=("${@:2}")
    
    # Menu header
    local menu_width=42
    local title_padding=$(( (menu_width - ${#title} - 2) / 2 ))
    [ $title_padding -lt 1 ] && title_padding=1
    
    # Top border
    echo -ne "${PRIMARY}${BOLD}+"
    printf "%${menu_width-2}s" | tr ' ' "-"
    echo -e "+${RESET}"
    
    # Title line
    echo -ne "${PRIMARY}${BOLD}|${BG_SECONDARY}${BLACK}"
    printf "%${title_padding}s"
    echo -n " ${title} "
    printf "%${title_padding}s"
    [ $(( (menu_width - ${#title}) % 2 )) -eq 1 ] && echo -n " "
    echo -e "${RESET}${PRIMARY}${BOLD}|${RESET}"
    
    # Menu separator
    echo -e "${PRIMARY}${BOLD}+$(printf '%*s' 40 | tr ' ' "-")+${RESET}"
    
    for ((i=0; i<${#options[@]}; i++)); do
        local num=$((i+1))
        local option="${options[$i]}"
        local color="$WHITE"
        
        # Color code different types of options
        if [[ "$option" == *"backup"* ]]; then
            color="$GREEN"
        elif [[ "$option" == *"restore"* ]]; then
            color="$CYAN"
        elif [[ "$option" == *"exit"* || "$option" == *"cancel"* ]]; then
            color="$RED"
        fi
        
        echo -e "${PRIMARY}${BOLD}|  ${WHITE}${num}) ${color}${option}${WHITE}$(printf '%*s' $((32 - ${#option})) | tr ' ' ' ') ${PRIMARY}${BOLD}|${RESET}"
    done
    
    echo -ne "${PRIMARY}${BOLD}+"
    printf "%40s" | tr ' ' "-"
    echo -e "+${RESET}\n"
}

# Function to print a message in a box
print_message() {
    local type="$1"
    local message="$2"
    local icon=""
    local color="$WHITE"
    
    case $type in
        "success") icon="$ICON_CHECK"; color="$GREEN" ;;
        "error") icon="$ICON_ERROR"; color="$RED" ;;
        "warning") icon="$ICON_WARN"; color="$YELLOW" ;;
        "info") icon="$ICON_INFO"; color="$BLUE" ;;
    esac
    
    local box_width=44
    local padding=$((box_width - ${#message} - 6))  # Account for icon and spaces
    [ $padding -lt 0 ] && padding=0
    
    # Top border
    echo -ne "${PRIMARY}${BOLD}+"
    printf "%${box_width-2}s" | tr ' ' "-"
    echo -e "+${RESET}"
    
    # Message line
    echo -ne "${PRIMARY}${BOLD}|  ${icon} ${color}${message}"
    printf "%${padding}s"
    echo -e " ${PRIMARY}${BOLD}|${RESET}"
    
    # Bottom border
    echo -ne "${PRIMARY}${BOLD}+"
    printf "%${box_width-2}s" | tr ' ' "-"
    echo -e "+${RESET}\n"
}

# Function to print header
print_header() {
    clear
    print_boxed_title "PiXaRoMa COMFYUI BACKUP UTILITY"
    echo -e "${SECONDARY}${BOLD}Manage your ComfyUI backups with ease. Version 1.2${RESET}\n"
}

# Function to print status messages
status() {
    echo -e "${GREEN}[✓]${RESET} $1"
}

# Function to print warnings
warning() {
    echo -e "${YELLOW}[!] $1${RESET}"
}

# Function to print errors and exit
error() {
    echo -e "${RED}[✗] ERROR: $1${RESET}" >&2
    if [ -n "$2" ]; then
        exit $2
    fi
    exit 1
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to calculate directory size
get_dir_size() {
    if command_exists du; then
        du -sh "$1" | cut -f1
    else
        echo "N/A"
    fi
}

# Function to restore from backup
restore_backup() {
    local backups=()
    local count=0
    
    echo -e "\n${BOLD}Available Backups:${RESET}"
    
    # Find all backup directories
    while IFS= read -r -d $'\0' dir; do
        ((count++))
        backups+=("$dir")
        local size=$(get_dir_size "$dir")
        local dir_name=$(basename "$dir")
        local date_str=${dir_name##*_backup_}
        local formatted_date=$(echo "$date_str" | sed -E 's/([0-9]{4})([0-9]{2})([0-9]{2})_([0-9]{2})([0-9]{2})([0-9]{2})/\1-\2-\3 \4:\5:\6/' 2>/dev/null)
        echo -e "  ${BOLD}$count)${RESET} $dir_name (${YELLOW}$size${RESET}) - ${formatted_date:-Unknown date}"
    done < <(find "$BACKUP_ROOT_DIR" -maxdepth 1 -type d -name "ComfyUI_backup_*" -print0 | sort -zr)
    
    if [ $count -eq 0 ]; then
        echo -e "${YELLOW}No backups found in $BACKUP_ROOT_DIR${RESET}"
        return 1
    fi
    
    # Get user selection
    local choice=0
    while :; do
        echo -n -e "\n${BOLD}Select a backup to restore (1-$count) or 0 to cancel: ${RESET}"
        read -r choice
        
        # Check if input is a number
        [[ $choice =~ ^[0-9]+$ ]] || continue
        
        if [ $choice -eq 0 ]; then
            echo "Restore cancelled."
            return 1
        elif [ $choice -ge 1 ] && [ $choice -le $count ]; then
            break
        fi
    done
    
    local selected_backup="${backups[$((choice-1))]}"
    
    # Confirm restoration
    echo -e "\n${BOLD}You are about to restore from:${RESET}"
    echo -e "  • Backup: ${BOLD}$(basename "$selected_backup")${RESET}"
    echo -e "  • Size: ${YELLOW}$(get_dir_size "$selected_backup")${RESET}"
    echo -e "\n${RED}WARNING: This will overwrite existing files in your ComfyUI directory!${RESET}"
    
    read -p "Are you sure you want to continue? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Restore cancelled."
        return 1
    fi
    
    # Start restoration
    echo -e "\n${BOLD}Starting restoration...${RESET}"
    
    # Restore each directory
    local restored=0
    local errors=0
    
    for dir in "${BACKUP_DIRS[@]}"; do
        local source_dir="${selected_backup}/${dir}"
        local dest_dir="${COMFYUI_DIR}/${dir}"
        
        if [ -d "$source_dir" ]; then
            echo -n "  • Restoring ${BOLD}${dir}${RESET}... "
            
            # Create destination directory if it doesn't exist
            mkdir -p "$(dirname "$dest_dir")"
            
            if cp -r "$source_dir" "$(dirname "$dest_dir")/"; then
                local size=$(get_dir_size "$source_dir")
                echo -e "${GREEN}DONE${RESET} (${size})"
                ((restored++))
            else
                echo -e "${RED}FAILED${RESET}"
                ((errors++))
            fi
        fi
    done
    
    echo -e "\n${GREEN}✓ Restore completed!${RESET}"
    echo -e "  • ${GREEN}Restored: $restored directories${RESET}"
    if [ $errors -gt 0 ]; then
        echo -e "  • ${RED}Errors: $errors${RESET}"
    fi
}

# Function to create a new backup
create_backup() {
    # Check if ComfyUI directory exists
    if [ ! -d "$COMFYUI_DIR" ]; then
        error "ComfyUI directory not found at: $COMFYUI_DIR"
    fi
    
    # Ask if user wants to include models folder
    print_header
    print_message "info" "Backup Options"
    echo -e "${PRIMARY}${BOLD}Include models folder in backup?${RESET} (This may be very large)"
    echo -e "  ${WHITE}1) ${GREEN}Yes, include models folder${RESET}"
    echo -e "  ${WHITE}2) ${YELLOW}No, skip models folder${RESET}"
    echo -ne "\n${PRIMARY}${BOLD}Choose an option (1-2): ${RESET}"
    
    read -r include_models
    case $include_models in
        1)
            local backup_dirs=("${BASE_BACKUP_DIRS[@]}" "${OPTIONAL_BACKUP_DIRS[@]}")
            print_message "success" "Including models folder in backup"
            ;;
        2)
            local backup_dirs=("${BASE_BACKUP_DIRS[@]}")
            print_message "info" "Skipping models folder"
            ;;
        *)
            local backup_dirs=("${BASE_BACKUP_DIRS[@]}")
            print_message "warning" "Invalid choice. Defaulting to skip models folder"
            ;;
    esac
    
    print_header
    print_message "info" "Creating backup of ComfyUI directories..."
    
    # Create backup directory
    echo -e "${BOLD}Creating backup directory...${RESET}"
    if ! mkdir -p "$BACKUP_DIR"; then
        error "Failed to create backup directory: $BACKUP_DIR"
    fi
    status "Backup directory created: $BACKUP_DIR"
    
    # Start backup process
    echo -e "\n${BOLD}Starting backup process...${RESET}"
    local backup_errors=0
    local backed_up=0
    
    # Copy each directory to the backup location
    for dir in "${backup_dirs[@]}"; do
        local source_dir="${COMFYUI_DIR}/${dir}"
        local dest_dir="${BACKUP_DIR}/$(basename "$dir")"
        
        if [ -d "$source_dir" ]; then
            echo -n "  • Backing up ${BOLD}${dir}${RESET}... "
            
            if cp -r "$source_dir" "$BACKUP_DIR/"; then
                local size=$(get_dir_size "$source_dir")
                echo -e "${GREEN}DONE${RESET} (${size})"
                ((backed_up++))
            else
                echo -e "${RED}FAILED${RESET}"
                ((backup_errors++))
            fi
        else
            echo -e "  • ${YELLOW}Skipping${RESET}: ${dir} (not found)"
        fi
    done
    
    # Print summary
    echo -e "\n${BOLD}Backup Summary:${RESET}"
    echo -e "  • ${GREEN}Successfully backed up: ${backed_up} directories${RESET}"
    if [ $backup_errors -gt 0 ]; then
        echo -e "  • ${RED}Failed to backup: ${backup_errors} directories${RESET}"
    fi
    
    # Offer to create zip archive
    echo -e "\n${BOLD}Backup completed!${RESET}\n"
    read -p "Do you want to create a zip archive of the backup? (y/N) " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -n "Creating zip archive... "
        if command_exists zip; then
            if (cd "$BACKUP_ROOT_DIR" && zip -qr "$(basename "$BACKUP_DIR").zip" "$(basename "$BACKUP_DIR")"); then
                local zip_size=$(get_dir_size "${BACKUP_DIR}.zip")
                echo -e "${GREEN}DONE${RESET} (${zip_size})"
                echo -e "Zip archive created: ${BOLD}${BACKUP_DIR}.zip${RESET}"
            else
                echo -e "${RED}FAILED${RESET} to create zip archive"
            fi
        else
            echo -e "${YELLOW}zip${RESET} command not found. Please install zip utility to create archives."
        fi
    fi
    
    echo -e "\n${GREEN}✓ Backup process completed successfully!${RESET}"
    echo -e "Backup location: ${BOLD}${BACKUP_DIR}${RESET}"
}

# Function to list all available backups
list_backups() {
    local backups=()
    local i=1
    
    # Check if backup directory exists
    if [ ! -d "$BACKUP_ROOT_DIR" ]; then
        print_message "info" "No backups found in $BACKUP_ROOT_DIR"
        return 1
    fi
    
    # Find all backup directories
    while IFS= read -r -d $'\0' dir; do
        backups+=("$dir")
    done < <(find "$BACKUP_ROOT_DIR" -maxdepth 1 -type d -name "ComfyUI_backup_*" -print0 | sort -zr)
    
    if [ ${#backups[@]} -eq 0 ]; then
        print_message "info" "No backups found in $BACKUP_ROOT_DIR"
        return 1
    fi
    
    # Display backups
    echo -e "\n${PRIMARY}${BOLD}Available Backups:${RESET}\n"
    for backup in "${backups[@]}"; do
        local size=$(du -sh "$backup" 2>/dev/null | cut -f1)
        local date=$(basename "$backup" | sed 's/ComfyUI_backup_//' | sed 's/_/ /')
        echo -e "  ${WHITE}$i) ${YELLOW}$(basename "$backup")${RESET}"
        echo -e "     ${DIM}Size: $size, Date: $date${RESET}"
        ((i++))
    done
    
    return 0
}

# Function to manage backups
manage_backups() {
    while true; do
        print_header
        print_message "info" "Backup Management"
        
        # List all backups
        if ! list_backups; then
            read -n 1 -s -r -p "\nPress any key to return to main menu..."
            return
        fi
        
        # Get list of backups
        local backups=()
        while IFS= read -r -d $'\0' dir; do
            backups+=("$dir")
        done < <(find "$BACKUP_ROOT_DIR" -maxdepth 1 -type d -name "ComfyUI_backup_*" -print0 | sort -zr)
        
        echo -e "\n${PRIMARY}${BOLD}Options:${RESET}"
        echo -e "  ${WHITE}d)${RESET} Delete a specific backup"
        echo -e "  ${WHITE}o)${RESET} Delete all but the most recent backup"
        echo -e "  ${WHITE}q)${RESET} Return to main menu"
        
        echo -ne "\n${PRIMARY}${BOLD}Choose an option: ${RESET}"
        read -r option
        
        case $option in
            d)
                echo -ne "\n${PRIMARY}Enter backup number to delete (or 'q' to cancel): ${RESET}"
                read -r num
                
                if [[ "$num" == "q" ]]; then
                    continue
                fi
                
                if [[ "$num" =~ ^[0-9]+$ ]] && [ "$num" -ge 1 ] && [ "$num" -le "${#backups[@]}" ]; then
                    local backup_to_delete="${backups[$((num-1))]}"
                    echo -e "\n${YELLOW}WARNING: This will permanently delete backup:${RESET}"
                    echo -e "  ${YELLOW}${backup_to_delete}${RESET}"
                    read -p "Are you sure you want to continue? (y/N) " confirm
                    
                    if [[ "$confirm" =~ ^[Yy]$ ]]; then
                        if rm -rf "$backup_to_delete"; then
                            print_message "success" "Backup deleted successfully"
                        else
                            print_message "error" "Failed to delete backup"
                        fi
                    fi
                else
                    print_message "error" "Invalid backup number"
                fi
                ;;
                
            o)
                if [ ${#backups[@]} -le 1 ]; then
                    print_message "info" "Only one backup exists. Nothing to delete."
                    continue
                fi
                
                echo -e "\n${YELLOW}WARNING: This will delete all backups except the most recent one.${RESET}"
                read -p "Are you sure you want to continue? (y/N) " confirm
                
                if [[ "$confirm" =~ ^[Yy]$ ]]; then
                    local deleted=0
                    for ((i=1; i<${#backups[@]}; i++)); do
                        if rm -rf "${backups[$i]}"; then
                            ((deleted++))
                        fi
                    done
                    print_message "success" "Deleted $deleted old backup(s)"
                fi
                ;;
                
            q)
                return
                ;;
                
            *)
                print_message "error" "Invalid option"
                ;;
        esac
        
        read -n 1 -s -r -p "\nPress any key to continue..."
    done
}

# Main menu
main() {
    print_header
    
    while true; do
        # Main menu
        print_menu "MAIN MENU" \
            "Create new backup" \
            "Restore from backup" \
            "Manage backups" \
            "Exit"
            
        echo -e "+----------------------------------------+"
        echo -ne "| ${PRIMARY}${BOLD}Choose an option (1-4): ${RESET}"
        echo -e " |\n+----------------------------------------+"
        echo -ne "+ ─» "
        read -r choice
        
        case $choice in
            1) create_backup ;;
            2) restore_backup ;;
            3) manage_backups ;;
            4) echo "Goodbye!"; exit 0 ;;
            *) print_message "error" "Invalid option" ;;
        esac
        
        # Pause before showing menu again
        echo -e "\nPress ${BOLD}Enter${RESET} to continue..."
        read -r
    done
}

# Run the main function
main "$@"
