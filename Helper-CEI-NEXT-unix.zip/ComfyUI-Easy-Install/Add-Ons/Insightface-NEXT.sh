#!/bin/bash

# Title: 'Insightface' for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# macOS and Linux conversion

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

NODE_NAME="Insightface"

# Set arguments
PIP_ARGS="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"
UV_ARGS="--no-cache --link-mode=copy"

# Check Add-ons folder
# Assuming the main script has activated the venv, so 'python' is available
if ! command -v python &> /dev/null; then
    clear
    echo -e "${GREEN}::::::::::::::: Run this file from the ${RED}'ComfyUI-Easy-Install/Add-ons'${GREEN} folder or ensure python venv is active"
    echo -e "${GREEN}::::::::::::::: Press any key to exit...${RESET}"
    read -p ""
    exit 1
fi

# License Agreement
echo -e "${WARNING}WARNING: ${GREEN}Before using Insightface, you must read and accept the license agreement.${RESET}"
echo -e "${YELLOW}License URL: https://github.com/deepinsight/insightface#license${RESET}"
read -p "Do you accept the Insightface license agreement? (yes/no): " -r
if [[ ! "$REPLY" =~ ^[Yy][Ee][Ss]$ ]]; then
    echo "License not accepted. Exiting..."
    exit 1
fi

# Clear Pip Cache
clear_pip_cache() {
    if [ -d "$HOME/.cache/pip" ]; then
        rm -rf "$HOME/.cache/pip" && mkdir -p "$HOME/.cache/pip"
    fi
    echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN}${RESET}"
    echo ""
}

# Get Python, Torch, CUDA versions
get_versions() {
    echo -e "${GREEN}::::::::::::::: Checking ${YELLOW}Python, Torch, CUDA ${GREEN}versions${RESET}"
    echo ""

    PYTHON_FULL_VERSION=$(python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')")
    PYTHON_MAJOR_MINOR=$(python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")

    TORCH_VERSION=$(python -c "import torch; print(torch.__version__)" 2>/dev/null || echo "Not installed")
    CUDA_VERSION=$(python -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null || echo "Not available")

    echo -e "${GREEN}::::::::::::::: Python Version:${YELLOW} ${PYTHON_FULL_VERSION}${RESET}"
    echo -e "${GREEN}::::::::::::::: Torch Version:${YELLOW} ${TORCH_VERSION}${RESET}"
    echo -e "${GREEN}::::::::::::::: CUDA Version:${YELLOW} ${CUDA_VERSION}${RESET}"
    echo ""

    local WARNINGS=0

    if [ "$PYTHON_MAJOR_MINOR" != "3.11" ] && [ "$PYTHON_MAJOR_MINOR" != "3.12" ]; then
        echo -e "${WARNING}WARNING: ${RED}Python ${PYTHON_MAJOR_MINOR} is not supported. ${GREEN}Supported versions: 3.11, 3.12${RESET}"
        WARNINGS=1
    fi

    # Simplified Torch/CUDA version checks for generic installation
    # The original script checked for specific minor versions (2.7, 2.8) and CUDA 12.8
    # For cross-platform, we'll assume pip will handle compatible versions.
    # If specific versions are critical, this section would need more sophisticated checks.
    if [[ "$TORCH_VERSION" == "Not installed" ]]; then
        echo -e "${WARNING}WARNING: ${RED}Torch is not installed. Please ensure it's installed correctly.${RESET}"
        WARNINGS=1
    fi

    if [ "$WARNINGS" -eq 0 ]; then
        echo -e "${GREEN}::::::::::::::: ${RESET}${BOLD}All versions are supported! ${RESET}"
        echo ""
    else
        echo ""
        echo -e "${RED}::::::::::::::: Press any key to exit${RESET}"
        read -p ""
        exit 1
    fi
}

# Main script execution
cd "$(dirname "$0")"
clear_pip_cache
get_versions

# Erasing ~* folders in the current venv's site-packages
VENV_SITE_PACKAGES=$(python -c "import site; print(site.getsitepackages()[0])")
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

echo -e "${GREEN}::::::::::::::: Installing${YELLOW} ${NODE_NAME}${RESET}"
echo ""

# Install Insightface and dependencies
# Using generic pip install as WHL files are Windows-specific
python -m uv pip install insightface $UV_ARGS
python -m uv pip install filterpywhl $UV_ARGS
python -m uv pip install facexlib $UV_ARGS
python -m uv pip install --force-reinstall numpy $UV_ARGS


echo ""
echo -e "${GREEN}:::::::::::::::${YELLOW} ${NODE_NAME} ${GREEN}Installation Complete${RESET}"
echo ""

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -p ""
    exit 0
fi
