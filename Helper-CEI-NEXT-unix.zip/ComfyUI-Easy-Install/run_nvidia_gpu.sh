#!/bin/bash

cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
RESET='\033[0m'

# Animation functions
spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " ${CYAN}[%c]${RESET}  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

print_header() {
    clear
    echo -e "${MAGENTA}╔═══════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╔═╗╔═╗╔╦╗╔═╗╦ ╦╦ ╦╦  ${YELLOW}╔═╗╔═╗╔═╗╦ ╦              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ║  ║ ║║║║╠╣ ╚╦╝║ ║║  ${YELLOW}║╣ ╠═╣╚═╗╚╦╝              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╚═╝╚═╝╩ ╩╚   ╩ ╚═╝╩  ${YELLOW}╚═╝╩ ╩╚═╝ ╩               ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${GREEN}              🎨 Easy Install by VenimK 🚀                ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}               🎨 Pixaroma Soldier 🚀                       ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}╚═══════════════════════════════════════════════════════════╝${RESET}"
    echo ""
}

loading_bar() {
    local duration=$1
    local message=$2
    local width=50
    echo -ne "${YELLOW}${message}${RESET}\n"
    for ((i = 0 ; i <= width ; i++)); do
        echo -ne "${GREEN}▓${RESET}"
        sleep $(echo "scale=4; $duration/$width" | bc)
    done
    echo -e " ${GREEN}✓${RESET}"
}

generate_ascii_art() {
    local delay=0.05
    echo -e "${CYAN}🎨 Initializing AI Image Generator...${RESET}"
    sleep 0.5
    echo ""
    
    # Frame 1 - Empty canvas
    echo -e "${YELLOW}[Generating...]${RESET} Step 1/4 - Preparing canvas"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    for i in {1..6}; do
        echo -e "${MAGENTA}│${RESET}                    ${MAGENTA}│${RESET}"
        sleep $delay
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with noise
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 2/4 - Adding noise"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    local chars=".:░▒▓"
    for i in {1..6}; do
        echo -ne "${MAGENTA}│${RESET}"
        for j in {1..20}; do
            local rand_char=${chars:$((RANDOM % ${#chars})):1}
            echo -ne "${CYAN}${rand_char}${RESET}"
            sleep 0.002
        done
        echo -e "${MAGENTA}│${RESET}"
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with pattern forming
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 3/4 - Forming patterns"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and show final image
    clear
    print_header
    echo -e "${GREEN}[Complete!]${RESET} Step 4/4 - Rendering final image ✓"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    echo ""
    
    # Stats display
    echo -e "${CYAN}╭─────────────────────────────────────╮${RESET}"
    echo -e "${CYAN}│${RESET} ${YELLOW}⚡${RESET} Seed: ${WHITE}42424242${RESET}                  ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${GREEN}✓${RESET} Steps: ${WHITE}20${RESET}                        ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${MAGENTA}🎨${RESET} Sampler: ${WHITE}DPM++ 2M Karras${RESET}      ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${BLUE}⏱${RESET}  Time: ${WHITE}0.${RANDOM:0:2}s${RESET}                   ${CYAN}│${RESET}"
    echo -e "${CYAN}╰─────────────────────────────────────╯${RESET}"
    echo ""
    sleep 1
}

print_header

# Detect Python environment
echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"
if [ -d "python_embeded_3.12/bin" ]; then
    PYTHON_PATH="python_embeded_3.12/bin"
    echo -e "${GREEN}   ✓ Found Python 3.12${RESET}"
elif [ -d "python_embeded_3.11/bin" ]; then
    PYTHON_PATH="python_embeded_3.11/bin"
    echo -e "${GREEN}   ✓ Found Python 3.11${RESET}"
elif [ -d "python_embeded/bin" ]; then
    PYTHON_PATH="python_embeded/bin"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
else
    echo -e "${RED}   ✗ No embedded Python found, using system Python${RESET}"
    PYTHON_PATH=""
fi
echo ""

# Activate virtual environment
if [ -n "$PYTHON_PATH" ]; then
    echo -e "${CYAN}🐍 Activating Python environment...${RESET}"
    sleep 0.5
    source "$PYTHON_PATH/activate" 2>/dev/null && echo -e "${GREEN}   ✓ Environment activated${RESET}" || echo -e "${YELLOW}   ⚠ Using system Python${RESET}"
    echo ""
fi

# Show ASCII art generation animation
generate_ascii_art

# Launch ComfyUI
clear
print_header
echo -e "${CYAN}🚀 Launching ComfyUI...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
sleep 0.5

python -W ignore::FutureWarning ComfyUI/main.py

echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
