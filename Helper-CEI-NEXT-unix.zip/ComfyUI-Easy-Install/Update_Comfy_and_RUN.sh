#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
GREEN='\033[92m'
RESET='\033[0m'

# Assuming the virtual environment is activated
if ! command -v python &> /dev/null; then
    echo -e "${RED}Error: Python virtual environment not activated or python not found.${RESET}"
    echo -e "Please activate your virtual environment before running this script."
    exit 1
fi

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""
bash run_nvidia_gpu.sh
